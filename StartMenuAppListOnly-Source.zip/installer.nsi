; Installer for "Start Menu: App List Only"  (NSIS 3, Unicode)
Unicode true
!define APPNAME   "Start Menu App List Only"
!define APPEXE    "StartMenuAppListOnly.exe"
!define VERSION   "1.2.0"
!define PUBLISHER "Tasmon Islam"
!define CONTACT   "tasmon@outlook.com"
!define UNINSTKEY "Software\Microsoft\Windows\CurrentVersion\Uninstall\StartMenuAppListOnly"

!include "MUI2.nsh"
!include "x64.nsh"
!include "WinVer.nsh"

Name "${APPNAME}"
OutFile "StartMenuAppListOnly-Setup-${VERSION}.exe"
InstallDir "$PROGRAMFILES64\${APPNAME}"
InstallDirRegKey HKLM "Software\StartMenuAppListOnly" "InstallDir"
RequestExecutionLevel admin
SetCompressor /SOLID lzma
BrandingText "${APPNAME} ${VERSION}"

VIProductVersion "1.2.0.0"
VIAddVersionKey "ProductName"     "${APPNAME}"
VIAddVersionKey "CompanyName"     "${PUBLISHER}"
VIAddVersionKey "FileDescription" "${APPNAME} Setup"
VIAddVersionKey "FileVersion"     "${VERSION}"
VIAddVersionKey "ProductVersion"  "${VERSION}"
VIAddVersionKey "LegalCopyright"  "Copyright (c) 2026 Tasmon Islam"
VIAddVersionKey "Comments"        "Developer: Tasmon Islam <${CONTACT}>"

!define MUI_ICON   "app.ico"
!define MUI_UNICON "app.ico"
!define MUI_ABORTWARNING

!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!define MUI_FINISHPAGE_RUN "$INSTDIR\${APPEXE}"
!define MUI_FINISHPAGE_RUN_TEXT "Open ${APPNAME} now"
!insertmacro MUI_PAGE_FINISH

!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "English"

Function .onInit
  ${IfNot} ${AtLeastWin10}
    MessageBox MB_ICONSTOP "This program requires Windows 10 or later."
    Abort
  ${EndIf}
FunctionEnd

Section "Install"
  SetRegView 64
  SetOutPath "$INSTDIR"
  File "StartMenuAppListOnly.exe"
  File "StartMenuAppListOnly.exe.config"
  File "app.ico"
  WriteUninstaller "$INSTDIR\Uninstall.exe"

  ; Start menu shortcuts (all users)
  SetShellVarContext all
  CreateDirectory "$SMPROGRAMS\${APPNAME}"
  CreateShortcut "$SMPROGRAMS\${APPNAME}\${APPNAME}.lnk" "$INSTDIR\${APPEXE}" "" "$INSTDIR\app.ico"
  CreateShortcut "$SMPROGRAMS\${APPNAME}\Uninstall ${APPNAME}.lnk" "$INSTDIR\Uninstall.exe"

  ; Programs and Features / Settings > Apps entry
  WriteRegStr   HKLM "Software\StartMenuAppListOnly" "InstallDir" "$INSTDIR"
  WriteRegStr   HKLM "${UNINSTKEY}" "DisplayName"          "${APPNAME}"
  WriteRegStr   HKLM "${UNINSTKEY}" "DisplayVersion"       "${VERSION}"
  WriteRegStr   HKLM "${UNINSTKEY}" "Publisher"            "${PUBLISHER}"
  WriteRegStr   HKLM "${UNINSTKEY}" "Contact"              "${CONTACT}"
  WriteRegStr   HKLM "${UNINSTKEY}" "HelpLink"             "mailto:${CONTACT}"
  WriteRegStr   HKLM "${UNINSTKEY}" "DisplayIcon"          "$INSTDIR\app.ico"
  WriteRegStr   HKLM "${UNINSTKEY}" "InstallLocation"      "$INSTDIR"
  WriteRegStr   HKLM "${UNINSTKEY}" "UninstallString"      '"$INSTDIR\Uninstall.exe"'
  WriteRegStr   HKLM "${UNINSTKEY}" "QuietUninstallString" '"$INSTDIR\Uninstall.exe" /S'
  WriteRegDWORD HKLM "${UNINSTKEY}" "NoModify" 1
  WriteRegDWORD HKLM "${UNINSTKEY}" "NoRepair" 1
  WriteRegDWORD HKLM "${UNINSTKEY}" "EstimatedSize" 400
SectionEnd

Section "Uninstall"
  SetRegView 64
  SetShellVarContext all

  ; Undo the Start menu changes first (restores original registry values, removes the startup task)
  IfFileExists "$INSTDIR\${APPEXE}" 0 +2
    ExecWait '"$INSTDIR\${APPEXE}" /revert /quiet'

  Delete "$SMPROGRAMS\${APPNAME}\${APPNAME}.lnk"
  Delete "$SMPROGRAMS\${APPNAME}\Uninstall ${APPNAME}.lnk"
  RMDir  "$SMPROGRAMS\${APPNAME}"

  Delete "$INSTDIR\${APPEXE}"
  Delete "$INSTDIR\StartMenuAppListOnly.exe.config"
  Delete "$INSTDIR\app.ico"
  Delete "$INSTDIR\Uninstall.exe"
  RMDir  "$INSTDIR"

  DeleteRegKey HKLM "${UNINSTKEY}"
  DeleteRegKey HKLM "Software\StartMenuAppListOnly"
SectionEnd
