#!/bin/bash
# Rebuild on Linux/macOS. Needs: mono-mcs, mono-devel (4.8 reference assemblies), nsis, python3 + pillow (only to regenerate assets).
set -e
[ -f app.res ] || python3 make_assets.py
R=/usr/lib/mono/4.8-api
mcs -nologo -target:winexe -optimize+ -platform:anycpu -out:StartMenuAppListOnly.exe -win32res:app.res \
    -noconfig -nostdlib -lib:$R -r:$R/mscorlib.dll -r:$R/System.dll -r:$R/System.Core.dll \
    -r:$R/System.Drawing.dll -r:$R/System.Windows.Forms.dll Program.cs
makensis -V2 installer.nsi
echo "Done: StartMenuAppListOnly-Setup-1.2.0.exe"
