"""Generates app.ico and app.res (manifest + icon + version info) for mcs/csc -win32res."""
import struct, io, sys
from PIL import Image, ImageDraw

VER = (1, 1, 0, 0)

# ---------- icon ----------
def draw(size):
    s = size * 4
    im = Image.new('RGBA', (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.rounded_rectangle([0, 0, s - 1, s - 1], radius=int(s * 0.22), fill=(0, 103, 192, 255))
    # app-list rows: small square + bar
    pad = s * 0.20
    rows = 4
    rh = (s - 2 * pad) / rows
    for i in range(rows):
        y = pad + i * rh
        sq = rh * 0.52
        d.rounded_rectangle([pad, y + (rh - sq) / 2, pad + sq, y + (rh + sq) / 2], radius=sq * 0.2, fill=(255, 255, 255, 255))
        bw = (s - 2 * pad) - sq * 1.7 - (i % 2) * s * 0.10
        d.rounded_rectangle([pad + sq * 1.4, y + rh * 0.36, pad + sq * 1.4 + bw, y + rh * 0.64], radius=rh * 0.14, fill=(255, 255, 255, 235))
    return im.resize((size, size), Image.LANCZOS)

sizes = [16, 24, 32, 48, 64, 128, 256]
def dib(im):
    # classic 32-bit icon DIB (BITMAPINFOHEADER + BGRA bottom-up + AND mask) for max compatibility
    w, h = im.size
    px = im.convert('RGBA').load()
    rows = b''
    for y in range(h - 1, -1, -1):
        rows += b''.join(struct.pack('<BBBB', px[x, y][2], px[x, y][1], px[x, y][0], px[x, y][3]) for x in range(w))
    mask = b'\0' * (((w + 31) // 32) * 4 * h)
    return struct.pack('<IiiHHIIiiII', 40, w, h * 2, 1, 32, 0, len(rows) + len(mask), 0, 0, 0, 0) + rows + mask

pngs = []
for sz in sizes:
    im = draw(sz)
    if sz >= 256:
        b = io.BytesIO(); im.save(b, 'PNG'); pngs.append((sz, b.getvalue()))
    else:
        pngs.append((sz, dib(im)))

# write .ico (PNG-compressed entries, valid on Vista+)
ico = struct.pack('<HHH', 0, 1, len(pngs))
off = 6 + 16 * len(pngs)
for sz, data in pngs:
    w = 0 if sz >= 256 else sz
    ico += struct.pack('<BBBBHHII', w, w, 0, 0, 1, 32, len(data), off)
    off += len(data)
ico += b''.join(d for _, d in pngs)
open('app.ico', 'wb').write(ico)

# ---------- .res builder ----------
def pad4(b): return b + b'\0' * ((4 - len(b) % 4) % 4)

def res_entry(rtype, rid, data, lang=0x0409):
    hdr_rest = struct.pack('<HH', 0xFFFF, rtype) + struct.pack('<HH', 0xFFFF, rid)
    hdr_rest = pad4(hdr_rest)
    tail = struct.pack('<IHHII', 0, 0x0030 if rtype != 24 else 0x0030, lang, 0, 0)
    header_size = 8 + len(hdr_rest) + len(tail)
    return pad4(struct.pack('<II', len(data), header_size) + hdr_rest + tail + data)

res = bytes.fromhex('00000000200000' + '00' + 'ffff0000ffff0000' + '00' * 16)  # null entry (32 bytes)
assert len(res) == 32

# manifest (RT_MANIFEST=24, id 1)
res += res_entry(24, 1, open('app.manifest', 'rb').read())

# icons: RT_ICON=3 ids 1..n, RT_GROUP_ICON=14
grp = struct.pack('<HHH', 0, 1, len(pngs))
for i, (sz, data) in enumerate(pngs, start=1):
    res += res_entry(3, i, data)
    w = 0 if sz >= 256 else sz
    grp += struct.pack('<BBBBHHIH', w, w, 0, 0, 1, 32, len(data), i)
res += res_entry(14, 1, grp)

# version info (RT_VERSION=16)
def block(key, value=b'', vlen=0, wtype=1, children=b''):
    d = struct.pack('<HHH', 0, vlen, wtype) + key.encode('utf-16le') + b'\0\0'
    d = pad4(d)
    if value: d += pad4(value)
    d += children
    d = struct.pack('<H', len(d)) + d[2:]
    return pad4(d)

def sstr(k, v):
    t = v.encode('utf-16le') + b'\0\0'
    return block(k, t, len(t) // 2)

strings = {
    'CompanyName': 'Tasmon Islam',
    'FileDescription': 'Start Menu: App List Only',
    'FileVersion': '.'.join(map(str, VER)),
    'InternalName': 'StartMenuAppListOnly',
    'LegalCopyright': 'Copyright (c) 2026 Tasmon Islam',
    'Comments': 'Developer: Tasmon Islam <tasmon@outlook.com>',
    'OriginalFilename': 'StartMenuAppListOnly.exe',
    'ProductName': 'Start Menu: App List Only',
    'ProductVersion': '.'.join(map(str, VER)),
}
st = block('040904B0', children=b''.join(sstr(k, v) for k, v in strings.items()))
sfi = block('StringFileInfo', children=st)
var = block('Translation', struct.pack('<HH', 0x0409, 0x04B0), 4, wtype=0)
vfi = block('VarFileInfo', children=var)
ms = (VER[0] << 16) | VER[1]; ls = (VER[2] << 16) | VER[3]
ffi = struct.pack('<13I', 0xFEEF04BD, 0x00010000, ms, ls, ms, ls, 0x3F, 0, 0x40004, 1, 0, 0, 0)
root = block('VS_VERSION_INFO', ffi, 52, wtype=0, children=sfi + vfi)
res += res_entry(16, 1, root)

open('app.res', 'wb').write(res)
print('assets ok', len(res), 'bytes')
