@echo off
rem Rebuild on Windows. Needs: .NET Framework 4.x (built in) and NSIS (https://nsis.sourceforge.io) on PATH.
setlocal
set CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe
"%CSC%" /nologo /target:winexe /optimize+ /platform:anycpu /out:StartMenuAppListOnly.exe /win32res:app.res ^
  /reference:System.dll /reference:System.Core.dll /reference:System.Drawing.dll /reference:System.Windows.Forms.dll Program.cs || goto :err
makensis /V2 installer.nsi || goto :err
echo Done: StartMenuAppListOnly-Setup-1.2.0.exe
exit /b 0
:err
echo Build failed.
exit /b 1
