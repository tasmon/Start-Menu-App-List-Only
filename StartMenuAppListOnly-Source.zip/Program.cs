using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Security;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;

[assembly: AssemblyTitle("Start Menu: App List Only")]
[assembly: AssemblyProduct("Start Menu: App List Only")]
[assembly: AssemblyCompany("Tasmon Islam")]
[assembly: AssemblyCopyright("Copyright (c) 2026 Tasmon Islam")]
[assembly: AssemblyDescription("Shows only the installed-apps list in the Windows 10 Start menu. Developer: Tasmon Islam <tasmon@outlook.com>")]
[assembly: AssemblyVersion("1.1.0.0")]
[assembly: AssemblyFileVersion("1.1.0.0")]

namespace StartMenuAppListOnly
{
    // =====================================================================
    //  Entry point:  no args -> GUI
    //  /apply | /revert | /status   [/quiet] [/reapply] [/norestart]
    //  Exit codes: 0 ok / applied, 1 error, 3 (status) not applied
    // =====================================================================
    static class Program
    {
        [STAThread]
        static int Main(string[] args)
        {
            string action = null;
            bool quiet = false, reapply = false, noRestart = false;
            foreach (string raw in args)
            {
                string a = raw.Trim().TrimStart('-', '/').ToLowerInvariant();
                switch (a)
                {
                    case "apply": case "revert": case "status": action = a; break;
                    case "quiet": case "q": case "silent": quiet = true; break;
                    case "reapply": reapply = true; break;
                    case "norestart": noRestart = true; break;
                }
            }

            if (action == null)
            {
                bool created;
                using (var mutex = new Mutex(true, "Global\\StartMenuAppListOnly.Gui", out created))
                {
                    if (!created) return 0;   // already open
                    Application.EnableVisualStyles();
                    Application.SetCompatibleTextRenderingDefault(false);
                    Application.Run(new MainForm());
                }
                return 0;
            }

            try
            {
                switch (action)
                {
                    case "apply":
                        Engine.Apply(reapply, !noRestart && !reapply);
                        if (!quiet) MessageBox.Show("Applied. Sign out and back in to finish.", "Start Menu: App List Only", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return 0;
                    case "revert":
                        Engine.Revert(!noRestart);
                        if (!quiet) MessageBox.Show("Restored. Sign out and back in to finish.", "Start Menu: App List Only", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return 0;
                    default:
                        return Engine.GetStatus().AllApplied ? 0 : 3;
                }
            }
            catch (Exception ex)
            {
                if (!quiet) MessageBox.Show(ex.Message, "Start Menu: App List Only", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 1;
            }
        }
    }

    // =====================================================================
    //  Engine: registry policy, layout file, scheduled task, backup/restore
    // =====================================================================
    class StatusInfo
    {
        public bool Locked, PinBlocked, TaskPresent;
        public bool AllApplied { get { return Locked && PinBlocked && TaskPresent; } }
        public bool AnyApplied { get { return Locked || PinBlocked || TaskPresent; } }
    }

    static class Engine
    {
        public const string TaskName = "StartMenuAppListOnly-Enforce";
        const string PinGuid = "{470C0EBD-5D73-4d58-9CED-E91E22E23282}";   // "Pin to Start" shell handler
        const string ExplorerPolicy = @"SOFTWARE\Policies\Microsoft\Windows\Explorer";
        const string CloudPolicy = @"SOFTWARE\Policies\Microsoft\Windows\CloudContent";
        const string BlockedExt = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked";

        public static readonly string DataDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "StartMenuAppListOnly");
        static string LayoutFile { get { return Path.Combine(DataDir, "EmptyStartLayout.xml"); } }
        static string BackupFile { get { return Path.Combine(DataDir, "backup.txt"); } }

        const string LayoutXml =
@"<?xml version=""1.0"" encoding=""utf-8""?>
<LayoutModificationTemplate
    xmlns:defaultlayout=""http://schemas.microsoft.com/Start/2014/FullDefaultLayout""
    xmlns:start=""http://schemas.microsoft.com/Start/2014/StartLayout""
    Version=""1""
    xmlns=""http://schemas.microsoft.com/Start/2014/LayoutModification"">
  <LayoutOptions StartTileGroupCellWidth=""6"" />
  <DefaultLayoutOverride>
    <StartLayoutCollection>
      <defaultlayout:StartLayout GroupCellWidth=""6"" />
    </StartLayoutCollection>
  </DefaultLayoutOverride>
</LayoutModificationTemplate>
";

        class Setting
        {
            public RegistryView View;
            public string SubKey, Name;
            public RegistryValueKind Kind;
            public object Value;
            public Setting(RegistryView v, string sub, string name, RegistryValueKind kind, object value)
            { View = v; SubKey = sub; Name = name; Kind = kind; Value = value; }
        }

        static List<Setting> Settings()
        {
            return new List<Setting> {
                new Setting(RegistryView.Registry64, ExplorerPolicy, "LockedStartLayout", RegistryValueKind.DWord, 1),
                new Setting(RegistryView.Registry64, ExplorerPolicy, "StartLayoutFile",   RegistryValueKind.String, LayoutFile),
                new Setting(RegistryView.Registry64, CloudPolicy,    "DisableWindowsConsumerFeatures", RegistryValueKind.DWord, 1),
                new Setting(RegistryView.Registry64, BlockedExt, PinGuid, RegistryValueKind.String, ""),
                new Setting(RegistryView.Registry32, BlockedExt, PinGuid, RegistryValueKind.String, ""),
            };
        }

        static RegistryKey Hklm(RegistryView v) { return RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, v); }

        // ---------------- status ----------------
        public static StatusInfo GetStatus()
        {
            var s = new StatusInfo();
            using (var hk = Hklm(RegistryView.Registry64))
            {
                using (var k = hk.OpenSubKey(ExplorerPolicy))
                    s.Locked = k != null && Convert.ToInt32(k.GetValue("LockedStartLayout", 0)) == 1;
                using (var k = hk.OpenSubKey(BlockedExt))
                    s.PinBlocked = k != null && Array.IndexOf(k.GetValueNames(), PinGuid) >= 0;
            }
            s.TaskPresent = RunHidden("schtasks.exe", "/Query /TN \"" + TaskName + "\"") == 0;
            return s;
        }

        public static bool HasBackup { get { return File.Exists(BackupFile); } }

        // ---------------- apply ----------------
        public static void Apply(bool reapply, bool restartExplorer)
        {
            Directory.CreateDirectory(DataDir);
            if (!File.Exists(BackupFile)) SaveBackup();        // keep the TRUE original state
            File.WriteAllText(LayoutFile, LayoutXml, new UTF8Encoding(true));

            foreach (var s in Settings())
                using (var hk = Hklm(s.View))
                using (var k = hk.CreateSubKey(s.SubKey))
                    k.SetValue(s.Name, s.Value, s.Kind);

            if (!reapply) RegisterTask();
            if (restartExplorer) RestartExplorer();
        }

        // ---------------- revert ----------------
        public static void Revert(bool restartExplorer)
        {
            if (File.Exists(BackupFile)) RestoreBackup();
            else foreach (var s in Settings()) DeleteValue(s.View, s.SubKey, s.Name);

            RunHidden("schtasks.exe", "/Delete /TN \"" + TaskName + "\" /F");
            try { if (Directory.Exists(DataDir)) Directory.Delete(DataDir, true); } catch { }
            if (restartExplorer) RestartExplorer();
        }

        // ---------------- backup (tab-separated, values base64) ----------------
        static void SaveBackup()
        {
            var sb = new StringBuilder();
            foreach (var s in Settings())
            {
                bool existed = false; string kind = "", val = "";
                using (var hk = Hklm(s.View))
                using (var k = hk.OpenSubKey(s.SubKey))
                {
                    if (k != null && Array.IndexOf(k.GetValueNames(), s.Name) >= 0)
                    {
                        existed = true;
                        kind = k.GetValueKind(s.Name).ToString();
                        object v = k.GetValue(s.Name, null, RegistryValueOptions.DoNotExpandEnvironmentNames);
                        val = Convert.ToBase64String(Encoding.UTF8.GetBytes(Convert.ToString(v)));
                    }
                }
                sb.AppendLine(string.Join("\t", new[] { s.View.ToString(), s.SubKey, s.Name, existed ? "1" : "0", kind, val }));
            }
            File.WriteAllText(BackupFile, sb.ToString(), Encoding.UTF8);
        }

        static void RestoreBackup()
        {
            foreach (string line in File.ReadAllLines(BackupFile))
            {
                string[] p = line.Split('\t');
                if (p.Length < 6) continue;
                var view = (RegistryView)Enum.Parse(typeof(RegistryView), p[0]);
                if (p[3] == "1")
                {
                    var kind = (RegistryValueKind)Enum.Parse(typeof(RegistryValueKind), p[4]);
                    string text = Encoding.UTF8.GetString(Convert.FromBase64String(p[5]));
                    object value = kind == RegistryValueKind.DWord ? (object)int.Parse(text) : text;
                    using (var hk = Hklm(view))
                    using (var k = hk.CreateSubKey(p[1]))
                        k.SetValue(p[2], value, kind);
                }
                else DeleteValue(view, p[1], p[2]);
            }
        }

        static void DeleteValue(RegistryView view, string sub, string name)
        {
            using (var hk = Hklm(view))
            using (var k = hk.OpenSubKey(sub, true))
                if (k != null) k.DeleteValue(name, false);
        }

        // ---------------- scheduled task (re-applies after updates / reboots) ----------------
        static void RegisterTask()
        {
            string exe = SecurityElement.Escape(Application.ExecutablePath);
            string xml =
"<?xml version=\"1.0\" encoding=\"UTF-16\"?>\r\n" +
"<Task version=\"1.2\" xmlns=\"http://schemas.microsoft.com/windows/2004/02/mit/task\">\r\n" +
"  <RegistrationInfo><Description>Re-applies the Start menu app-list-only policy.</Description></RegistrationInfo>\r\n" +
"  <Triggers><BootTrigger><Enabled>true</Enabled></BootTrigger><LogonTrigger><Enabled>true</Enabled></LogonTrigger></Triggers>\r\n" +
"  <Principals><Principal id=\"Author\"><UserId>S-1-5-18</UserId><RunLevel>HighestAvailable</RunLevel></Principal></Principals>\r\n" +
"  <Settings><MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy><DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>" +
"<StopIfGoingOnBatteries>false</StopIfGoingOnBatteries><ExecutionTimeLimit>PT5M</ExecutionTimeLimit><Enabled>true</Enabled></Settings>\r\n" +
"  <Actions Context=\"Author\"><Exec><Command>" + exe + "</Command><Arguments>/apply /reapply /quiet</Arguments></Exec></Actions>\r\n" +
"</Task>";
            string tmp = Path.Combine(Path.GetTempPath(), "smalo-task-" + Guid.NewGuid().ToString("N") + ".xml");
            try
            {
                File.WriteAllText(tmp, xml, Encoding.Unicode);
                int rc = RunHidden("schtasks.exe", "/Create /TN \"" + TaskName + "\" /XML \"" + tmp + "\" /F");
                if (rc != 0) throw new InvalidOperationException("Could not create the startup task (schtasks exit code " + rc + ").");
            }
            finally { try { File.Delete(tmp); } catch { } }
        }

        // ---------------- helpers ----------------
        public static void RestartExplorer()
        {
            foreach (var p in Process.GetProcessesByName("explorer"))
            { try { p.Kill(); } catch { } }
        }

        static int RunHidden(string file, string args)
        {
            var psi = new ProcessStartInfo(Path.Combine(Environment.SystemDirectory, file), args)
            {
                CreateNoWindow = true, UseShellExecute = false,
                RedirectStandardOutput = true, RedirectStandardError = true
            };
            try
            {
                using (var p = Process.Start(psi))
                {
                    p.StandardOutput.ReadToEnd(); p.StandardError.ReadToEnd();
                    p.WaitForExit(30000);
                    return p.ExitCode;
                }
            }
            catch { return -1; }
        }
    }

    // =====================================================================
    //  GUI: DPI-aware, auto-sizing, scrolls instead of cropping
    // =====================================================================
    class MainForm : Form
    {
        class Wrap { public Label L; public Control Beside; }

        readonly List<Wrap> wraps = new List<Wrap>();
        TableLayoutPanel root;
        Label badge;
        readonly Label[] dots = new Label[3];
        Button btnApply, btnRevert, btnClose;

        static readonly Color Accent = Color.FromArgb(0, 103, 192);
        static readonly Color Good = Color.FromArgb(16, 124, 16);
        static readonly Color Bad = Color.FromArgb(150, 150, 150);

        public MainForm()
        {
            AutoScaleDimensions = new SizeF(96F, 96F);
            AutoScaleMode = AutoScaleMode.Dpi;
            Font = new Font("Segoe UI", 9F);
            Text = "Start Menu: App List Only";
            StartPosition = FormStartPosition.CenterScreen;
            AutoScroll = true;
            BackColor = SystemColors.Window;
            MinimumSize = new Size(380, 320);
            ClientSize = new Size(540, 560);
            try { Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { }

            BuildUi();
            Load += delegate { FitToScreen(); FitWraps(); RefreshStatus(); };
            Resize += delegate { FitWraps(); };
        }

        // ----- UI construction -----
        void BuildUi()
        {
            root = new TableLayoutPanel
            {
                Dock = DockStyle.Top, AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink,
                ColumnCount = 1, BackColor = SystemColors.Window, Margin = Padding.Empty
            };
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));

            // header band
            var header = new TableLayoutPanel
            {
                Dock = DockStyle.Fill, AutoSize = true, ColumnCount = 1, BackColor = Accent,
                Padding = new Padding(24, 20, 24, 20), Margin = Padding.Empty
            };
            var title = new Label
            {
                Text = "Start Menu: App List Only", AutoSize = true, ForeColor = Color.White,
                Font = new Font("Segoe UI Semibold", 15F), Margin = new Padding(0, 0, 0, 4)
            };
            var sub = MakeWrap("Remove every Start tile and keep just the installed-apps list.", Color.FromArgb(225, 238, 250), header, null);
            sub.Margin = Padding.Empty;
            header.Controls.Add(title);
            header.Controls.Add(sub);
            root.Controls.Add(header);

            // description
            var desc = MakeWrap(
                "Turns the Windows 10 Start menu into a plain list of installed apps. Tiles are removed and locked, " +
                "and \"Pin to Start\" is blocked everywhere, including context menus. The change is system-wide, survives " +
                "restarts and updates, and can be undone at any time.", SystemColors.ControlText, root, null);
            desc.Margin = new Padding(24, 18, 24, 6);
            root.Controls.Add(desc);

            // status card
            var card = new Panel
            {
                BorderStyle = BorderStyle.FixedSingle, AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Dock = DockStyle.Fill, Margin = new Padding(24, 10, 24, 6), Padding = new Padding(12, 10, 12, 10)
            };
            var cardTable = new TableLayoutPanel
            {
                Dock = DockStyle.Top, AutoSize = true, ColumnCount = 2, Margin = Padding.Empty
            };
            cardTable.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            cardTable.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            badge = new Label
            {
                AutoSize = true, Font = new Font("Segoe UI Semibold", 12F), Margin = new Padding(0, 0, 0, 8)
            };
            cardTable.Controls.Add(badge, 0, 0);
            cardTable.SetColumnSpan(badge, 2);

            string[] labels = {
                "Start tiles removed and layout locked",
                "\"Pin to Start\" blocked in context menus",
                "Startup task keeps the setting in place"
            };
            for (int i = 0; i < 3; i++)
            {
                dots[i] = new Label { Text = "\u25CF", AutoSize = true, Margin = new Padding(0, 2, 8, 2), ForeColor = Bad };
                cardTable.Controls.Add(dots[i], 0, i + 1);
                var t = MakeWrap(labels[i], SystemColors.ControlText, cardTable, dots[i]);
                t.Margin = new Padding(0, 2, 0, 2);
                cardTable.Controls.Add(t, 1, i + 1);
            }
            card.Controls.Add(cardTable);
            // inner table lives inside the bordered panel: account for its padding + border in wraps
            root.Controls.Add(card);

            // buttons (wrap to new line on narrow windows)
            var buttons = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill, AutoSize = true, WrapContents = true,
                FlowDirection = FlowDirection.LeftToRight, Margin = new Padding(24, 12, 24, 4)
            };
            btnApply = MakeButton("Apply changes", true);
            btnRevert = MakeButton("Restore default", false);
            btnClose = MakeButton("Close", false);
            btnApply.Click += delegate { RunAction(true); };
            btnRevert.Click += delegate { RunAction(false); };
            btnClose.Click += delegate { Close(); };
            buttons.Controls.AddRange(new Control[] { btnApply, btnRevert, btnClose });
            root.Controls.Add(buttons);

            var note = MakeWrap(
                "After applying or restoring, sign out and back in so Windows rebuilds the Start menu. " +
                "Your previous tile arrangement is not brought back by Restore; you can re-pin tiles afterwards.",
                Color.FromArgb(96, 96, 96), root, null);
            note.Margin = new Padding(24, 8, 24, 4);
            root.Controls.Add(note);

            const string contact = "tasmon@outlook.com";
            string line = "Version 1.1.0  \u00B7  Tasmon Islam  \u00B7  " + contact;
            var ver = new LinkLabel
            {
                Text = line, AutoSize = true, ForeColor = Color.FromArgb(110, 110, 110),
                LinkColor = Accent, ActiveLinkColor = Color.FromArgb(0, 70, 140),
                Margin = new Padding(24, 4, 24, 18)
            };
            ver.Links.Add(line.Length - contact.Length, contact.Length, "mailto:" + contact);
            ver.LinkClicked += delegate (object s, LinkLabelLinkClickedEventArgs e)
            {
                try { Process.Start((string)e.Link.LinkData); } catch { }
            };
            wraps.Add(new Wrap { L = ver });
            root.Controls.Add(ver);

            Controls.Add(root);
        }

        Label MakeWrap(string text, Color color, Control parent, Control beside)
        {
            var l = new Label { Text = text, AutoSize = true, ForeColor = color, Margin = Padding.Empty };
            wraps.Add(new Wrap { L = l, Beside = beside });
            return l;
        }

        Button MakeButton(string text, bool primary)
        {
            var b = new Button
            {
                Text = text, AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Padding = new Padding(14, 5, 14, 5), Margin = new Padding(0, 0, 10, 8),
                MinimumSize = new Size(110, 0), UseVisualStyleBackColor = true
            };
            if (primary) { b.BackColor = Accent; b.ForeColor = Color.White; b.FlatStyle = FlatStyle.Flat; b.FlatAppearance.BorderColor = Accent; b.UseVisualStyleBackColor = false; }
            return b;
        }

        // ----- responsiveness -----
        // Wrapping labels need a max width; recompute from the real client width at the current DPI.
        void FitWraps()
        {
            int avail = ClientSize.Width - SystemInformation.VerticalScrollBarWidth;
            SuspendLayout();
            foreach (var w in wraps)
            {
                int reserved = 0;
                for (Control c = w.L; c != null && c.Parent != null && c != this; c = c.Parent)
                {
                    reserved += c.Margin.Horizontal + c.Parent.Padding.Horizontal;
                    if (c.Parent is Panel && ((Panel)c.Parent).BorderStyle != BorderStyle.None) reserved += 4;
                    if (c.Parent == this) break;
                }
                if (w.Beside != null) reserved += w.Beside.Width + w.Beside.Margin.Horizontal;
                w.L.MaximumSize = new Size(Math.Max(60, avail - reserved), 0);
            }
            ResumeLayout(true);
        }

        // Size the window to its content, never larger than the screen's working area.
        void FitToScreen()
        {
            Rectangle wa = Screen.FromControl(this).WorkingArea;
            FitWraps();
            Size pref = root.GetPreferredSize(new Size(ClientSize.Width, 0));
            Size frame = new Size(Width - ClientSize.Width, Height - ClientSize.Height);
            int w = Math.Min(ClientSize.Width + frame.Width, wa.Width);
            int h = Math.Min(pref.Height + frame.Height, wa.Height);
            Size = new Size(w, h);
            Location = new Point(wa.Left + (wa.Width - w) / 2, wa.Top + (wa.Height - h) / 2);
        }

        // ----- behaviour -----
        void RefreshStatus()
        {
            StatusInfo s = Engine.GetStatus();
            dots[0].ForeColor = s.Locked ? Good : Bad;
            dots[1].ForeColor = s.PinBlocked ? Good : Bad;
            dots[2].ForeColor = s.TaskPresent ? Good : Bad;
            if (s.AllApplied) { badge.Text = "Applied"; badge.ForeColor = Good; }
            else if (s.AnyApplied) { badge.Text = "Partially applied"; badge.ForeColor = Color.FromArgb(180, 110, 0); }
            else { badge.Text = "Not applied (Windows default)"; badge.ForeColor = Color.FromArgb(70, 70, 70); }
            btnApply.Enabled = !s.AllApplied;
            btnRevert.Enabled = s.AnyApplied || Engine.HasBackup;
        }

        void RunAction(bool apply)
        {
            btnApply.Enabled = btnRevert.Enabled = btnClose.Enabled = false;
            UseWaitCursor = true;
            Application.DoEvents();
            try
            {
                if (apply) Engine.Apply(false, true); else Engine.Revert(true);
                UseWaitCursor = false;
                RefreshStatus();
                string msg = apply ? "Tiles removed and pinning disabled." : "Start menu restored to the Windows default.";
                if (MessageBox.Show(this, msg + "\n\nSign out now to finish?", Text,
                        MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    Process.Start(Path.Combine(Environment.SystemDirectory, "shutdown.exe"), "/l");
            }
            catch (Exception ex)
            {
                UseWaitCursor = false;
                MessageBox.Show(this, "The operation failed:\n\n" + ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                UseWaitCursor = false;
                btnClose.Enabled = true;
                RefreshStatus();
            }
        }
    }
}
